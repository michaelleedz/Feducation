 <?php
return array(
	//'配置项'=>'配置值'
	'DB_TYPE'=>'mysql',
	'DB_HOST'=>'localhost',
	'DB_NAME'=>'fedu',
	'DB_USER'=>'root',
	'DB_PWD'=>'',
	'DB_CHARSET'=>'utf8',
	'URL_ROUTER_ON'=>true,
	'URL_ROUTER_RULES'=>array(
		'regist/:name'=>'Index/read',
		'regist/:password'=>'Index/read',
		'regist/:email'=>'Index/read',
		'regist/:tel'=>'Index/read',
		),

	'SHOW_PAGE_TRACE'=>true,
	'URL_MODEL'=>'2',
	// 'TMPL_L_DELIM'=>'<{',
	// 'TMPL_R_DELIM'=>'}>'

);