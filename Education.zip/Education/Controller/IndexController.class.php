<?php
namespace Education\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index0(){
        $this->show('<style type="text/css">*{ padding: 0; margin: 0; } div{ padding: 4px 48px;} body{ background: #fff; font-family: "微软雅黑"; color: #333;font-size:24px} h1{ font-size: 100px; font-weight: normal; margin-bottom: 12px; } p{ line-height: 1.8em; font-size: 36px }</style><div style="padding: 24px 48px;"> <h1>:)</h1><p>欢迎使用 <b>ThinkPHP</b>！</p><br/>[ 您现在访问的是Home模块的Index控制器 ]</div><script type="text/javascript" src="http://tajs.qq.com/stats?sId=9347272" charset="UTF-8"></script>','utf-8');
    }

    public function index1(){
      $t=M('Testimonial');
      $list=$t->select();
      $this->assign('list',$list);

    	$this->display();
    }

    public function log(){
      session(null);
      $this->display();
    }

    public function Dolog(){
      

      $name=$_POST['name'];
      $password=$_POST['password'];

      if ($name=='admin'&&$password=='administration') {
        session('name',$name);
        session('password',$password);
        redirect(__CONTROLLER__.'/groupindex');
      }
      else{
        redirect(__CONTROLLER__.'/login');
      }

    }

    public function Logout(){
      session('name',null);
      session('password',null);
      redirect(__CONTROLLER__.'/login');

    }

    public function Index(){

      $this->display();

    }

    public function Details(){


      $this->display();

    }


    public function About(){

      $this->display();


    }

    public function Blog(){

      $G=M("Groups");

      $count=$G->count();
      $Page=new \Think\Page($count,3);
      $show=$Page->show();
      $list=$G->limit($Page->firstRow.','.$Page->listRows)->select();

     //$list=$G->select();
      $this->assign('list',$list);
      $this->assign('page',$show);
      $this->display();

    }

    //  public function groupindex(){

    //   // if(session('name')==null){
    //   //   redirect(__CONTROLLER__.'/login');
    //   // }
    //   $g=M('Groups');
    //   $map['topic']=array('LIKE','%'.$_POST['wor'].'%' );
    //   $count=$g->where($map)->count();
    //   $Page=new \Think\Page($count,5);
    //   $show=$Page->show();
    //   $list=$g->where($map)->limit($Page->firstRow.','.$Page->listRows)->select();
    //   $this->assign('list',$list);
    //   $this->assign('page',$show);
    //   $this->display();
    // }




    public function Contracts(){
    	$this->display();
    }

    public function News(){
      $g=M('Groups');
     // $list=$g->select();
      $count=$g->count();
      $Page=new \Think\Page($count,5);
      $show=$Page->show();
     $list=$g->limit($Page->firstRow.','.$Page->listRows)->select();
      $this->assign('list',$list);  
      $this->assign('page',$show);
    	$this->display();
    }

    public function Newsdetail(){
      $g=M('Groups');
      $data=$g->find($_GET['id']);

      $this->assign('data',$data);
      $this->display();

    }
    // public function News(){

    //   $g=M('Groups');
    //   $list=$g->select();

    //   $this->assign('list',$list);
    //   $this->display();
    // }

    public function Products(){
      $p=M('Picture');
      $list=$p->select();
      $this->assign('list',$list);

    	$this->display();
    }

    public function Prodetail(){
    $p=M('Picture');

    $id=$_GET['id'];
    $info=$p->find($id);
    //var_dump($info);
    $list=explode('&', $info['image']);
    $this->assign('list',$list);
    $this->assign('data',$info);
    // $info1=$p->limit(2)->order('id desc')->select();
    // $this->assign('info1',$info1);
   $this->display();
    }


      public function upload(){
    $this->display();
  }

  public function doupload()
  {
    $pic=M('Picture');


    $upload=new \Think\Upload();
    $upload->maxSize=314572893;
    $upload->exts=array('jpg','gif','png','jpeg');

    foreach ($_FILES as $key => $file)
     {
      if (!empty($file['name'])) 
      {
        $info=$upload->uploadOne($file);
        if ($info) 
        {
            echo "info";
             var_dump($info);
          $img=new \Think\Image();
          $path=$info['savepath'].$info['savename'];
          $img->open('Uploads/'.$path);
          $filepath='Public/Uploads/tiny/'.mt_rand(1,3000).'.jpg';
          $img->thumb(380,300,\Think\Image::IMAGE_THUMB_FILLED)->save('./'.$filepath);
          $arr.=$filepath.'&';
          $image.=$path.'&';
          $this->assign('info',$info);   
         }
      }

    }

    var_dump($arr);
      $list=rtrim($arr,'&');
      $pic->pic=$list;
      $lis=rtrim($image,'&');
      $pic->image=$lis;
      $list=explode('&', $list);
       $pic->face=$list['0'];

      $pic->topic=$_POST['topic'];
      $pic->content=$_POST['content'];
      $pic->createtime=date('y-m-d');


      $pic->add();
      //var_dump($pic);
      print_r($pic->content);
      print_r($pic->topic);
      print_r($pic->face);
      print_r($pic->pic);
      print_r($pic->image);

      // print_r($list['0']);
      // var_dump($list);
      $this->assign('list',$list);
     redirect(__CONTROLLER__.'/backindex');

  }

    public function Services(){
    	$this->display();
    }

     public function backindex(){

      if(session('name')==null){
        redirect(__CONTROLLER__.'/login');
      }

      $p=M("Picture");
      if (!is_null($_POST['top'])) {
      $top=$_POST['top'];
      $map['topic']=array('LIKE','%'.$top.'%');
      }else{
        $map['topic']==null;
      }
      //var_dump($map);
      $count=$p->where($map)->count();
      $Page=new \Think\Page($count,5);
      $show=$Page->show();
      $list=$p->limit($Page->firstRow.','.$Page->listRows)->where($map)->select();

      $this->assign('list',$list);
      $this->assign('page',$show);
      $this->display();

    }

     public function picdelete(){

      $p=M('Picture');
      $id=$_GET['id'];

      $p->delete($id);

      redirect(__CONTROLLER__.'/backindex');



    }

  

     public function groupindex(){

      if(session('name')==null){
        redirect(__CONTROLLER__.'/login');
      }
      $g=M('Groups');
      $map['topic']=array('LIKE','%'.$_POST['wor'].'%' );
      $count=$g->where($map)->count();
      $Page=new \Think\Page($count,5);
      $show=$Page->show();
      $list=$g->where($map)->limit($Page->firstRow.','.$Page->listRows)->select();
      $this->assign('list',$list);
      $this->assign('page',$show);
      $this->display();
    }

    public function groupadd(){

      if(session('name')==null){
        redirect(__CONTROLLER__.'/login');
      }
      $this->display();
    }

    public function dogroupadd(){
      $g=M('Groups');
      $g->word=$_POST['word'];
      $g->topic=$_POST['topic'];
      $upload=new \Think\Upload();
      $upload->maxSize=31457289;
      $upload->exts=array('jpg','gif','jpeg','png');
      $info=$upload->upload();

      $img=new \Think\Image();
      $path=$info['photo']['savepath'].$info['photo']['savename'];
      $img->open('Uploads/'.$path);

       

       $filepath2='Public/Uploads/tiny2/'.mt_rand(1,2000).'.jpg';
      $img->thumb(380,300,\Think\Image::IMAGE_THUMB_FILLED)->save('./'.$filepath2);

      $filepath='Public/Uploads/tiny/'.mt_rand(1,3000).'.jpg';
      $img->thumb(180,141,\Think\Image::IMAGE_THUMB_FILLED)->save('./'.$filepath);
      
      $filepath1='Public/Uploads/tiny1/'.mt_rand(1,2000).'.jpg';
      $img->thumb(60,60,\Think\Image::IMAGE_THUMB_FILLED)->save('./'.$filepath1);
      
      $g->img2=$filepath2;
      $g->img=$filepath;
      $g->img1=$filepath1;
      $g->add();
      redirect(__CONTROLLER__.'/groupindex');
    }

    public function groupdelete(){
      $g=M('Groups');
      $id=$_GET['id'];
      $g->delete($id);
      redirect(__CONTROLLER__.'/groupindex');
    }

    public function groupedit(){

      if(session('name')==null){
        redirect(__CONTROLLER__.'/login');
      }
      $g=M('Groups');

      $id=$_GET['id'];
      $info=$g->find($id);
      $this->assign('info',$info);
      $this->display();
    }

    public function groupup(){
      $g=M('Groups');
      $go['id']=$_POST['id'];
      $go['topic']=$_POST['topic'];
      $go['word']=$_POST['word'];
      $upload=new \Think\Upload();
      $upload->maxSize=31457289;
      $upload->exts=array('jpg','gif','jpeg');
      $info=$upload->upload();

       if ($_FILES['photo']['error']==0)
       {
      $img=new \Think\Image();
      $path=$info['photo']['savepath'].$info['photo']['savename'];
      $img->open('Uploads/'.$path);
      $filepath2='Public/Uploads/tiny2/'.mt_rand(1,2000).'.jpg';
      $img->thumb(380,300,\Think\Image::IMAGE_THUMB_FILLED)->save('./'.$filepath2);
      $filepath='Public/Uploads/tiny/'.mt_rand(1,3000).'.jpg';
      $img->thumb(180,141,\Think\Image::IMAGE_THUMB_FILLED)->save('./'.$filepath);
      $filepath1='Public/Uploads/tiny1/'.mt_rand(1,2000).'.jpg';
      $img->thumb(60,60,\Think\Image::IMAGE_THUMB_FILLED)->save('./'.$filepath1);
      
      $go['img2']=$filepath2;     
      $go['img']=$filepath;
      $go['img1']=$filepath1;
      }elseif($_FILES['photo']['error']==4){
        $go['img']=$_POST['img'];
        $go['img1']=$_POST['img1'];
      }
      $num=$g->save($go);
      //var_dump($g);
      // var_dump($go);
      // print_r($num);
      if ($num>0) {
      $this->success('更新成功','groupindex');
        
      }
    }

    public function testindex(){

      if(session('name')==null){
        redirect(__CONTROLLER__.'/login');
      }
      $t=M('Testimonial');

      $list=$t->select();

      $this->assign('list',$list);

      $this->display();
    }

    public function testdelete(){
      $t=M('Testimonial');
      $t->delete($_GET['id']);

      redirect(__CONTROLLER__.'/testindex');
    }

    public function testadd(){

      if(session('name')==null){
        redirect(__CONTROLLER__.'/login');
      }
      $this->display();
    }

    public function dotestadd(){
      $t=M('Testimonial');
      $t->name=$_POST['name'];
      $t->role=$_POST['role'];
      $t->content=$_POST['content'];

      $t->add();

      redirect(__CONTROLLER__.'/testindex');
    }

    public function testedit(){

      if(session('name')==null){
        redirect(__CONTROLLER__.'/login');
      }
      $t=M('Testimonial');
      $data=$t->find($_GET['id']);

      $this->assign('info',$data);

      $this->display();
    }

    public function testup(){
      $t=M('Testimonial');
      $test['id']=$_POST['id'];
      $test['name']=$_POST['name'];
      $test['role']=$_POST['role'];
      $test['content']=$_POST['content'];

      $num=$t->save($test);
      if ($num>0) {
      $this->success('更新成功！','testindex');   
      }
      
    }

    public function infoadd(){
      if(session('name')==null){
        redirect(__CONTROLLER__.'/login');
      }
      $i=M('info');
       $i->name=$_POST['name']; 
      $i->web=$_POST['web'];
      $i->email=$_POST['email'];
      $i->contents=$_POST['contents'];
      $i->add();

      redirect(__CONTROLLER__.'/Contacts');
    }

    public function infoindex(){
      // $i=M('Info');

      // $list=$i->select();

      // $this->assign('list',$list);

      // $this->display();
      if (session('name')==null) {
        redirect(__CONTROLLER__.'/login');
      }

      $p=M("Info");
      if (!is_null($_POST['top'])) {
      $top=$_POST['top'];
      $map['contents']=array('LIKE','%'.$top.'%');
      }else{
        $map['topic']==null;
      }
      //var_dump($map);
      $count=$p->where($map)->count();
      $Page=new \Think\Page($count,5);
      $show=$Page->show();
      $list=$p->limit($Page->firstRow.','.$Page->listRows)->where($map)->select();

      $this->assign('list',$list);
      $this->assign('page',$show);
      $this->display();
    }

    public function infodelete(){

      $i=M('Info');
      $i->delete($_GET['id']);

      redirect(__CONTROLLER__.'/infoindex');
    }

    
}